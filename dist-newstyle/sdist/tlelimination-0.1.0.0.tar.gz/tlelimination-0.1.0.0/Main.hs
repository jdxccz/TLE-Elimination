module Main where

import Graphics.Gloss

main:: IO ()
main = play backgroundColor 30 initialworld
    putStr "Welcome to TLE World"
